package registermail;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.sun.mail.util.MailSSLSocketFactory;

public class MailUtil implements Runnable {
	private String email;// 收件人信箱
	private String code;// 驗證碼

	public MailUtil(String email, String code) {
		this.email = email;
		this.code = code;
	}

	public void run() {
		// 1.建立連線物件javax.mail.Session
		// 2.建立郵件物件 javax.mail.Message
		// 3.傳送一封開通信件
		String from = "610513106@gms.ndhu.edu.tw";// 發件人電子信箱
		String host = "smtp.gmail.com"; // 指定傳送email的主機，此為gmail
		Properties properties = System.getProperties();// 獲取系統屬性
		properties.setProperty("mail.smtp.host", host);// 設定email伺服器
		properties.setProperty("mail.smtp.auth", "true");// 開啟認證
		try {
			MailSSLSocketFactory sf = new MailSSLSocketFactory();
			sf.setTrustAllHosts(true);
			properties.put("mail.smtp.ssl.enable", "true");
			properties.put("mail.smtp.ssl.socketFactory", sf);
			// 1.獲取預設session物件
			Session session = Session.getDefaultInstance(properties, new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("信箱", "密碼"); // 發件人信箱賬號、密碼
				}
			});
			// 2.建立信件物件
			Message message = new MimeMessage(session);
			// 2.1設定發件人
			message.setFrom(new InternetAddress(from));
			// 2.2設定接收人
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			// 2.3設定信件主題
			message.setSubject("帳號啟用");
			// 2.4設定信件內容
			String content = "<html><head></head><body><h1>這是一封啟用信件,啟用請點選以下連結</h1><h3><a href='http://localhost:8080/jspExercise/verification/MailVerification.jsp?code=" + code + "'>請點這裡</a></h3></body></html>";
			message.setContent(content, "text/html;charset=UTF-8");
			// 3.傳送信件
			Transport.send(message);
			System.out.println("信件成功傳送!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
